export BLURFACTOR='0x4'

convert camel_1.jpg -blur $BLURFACTOR camel_1.blur_1.jpg
convert camel_1.blur_1.jpg -blur $BLURFACTOR camel_1.blur_2.jpg
convert camel_1.blur_2.jpg -blur $BLURFACTOR camel_1.blur_3.jpg
convert camel_1.blur_3.jpg -blur $BLURFACTOR camel_1.blur_4.jpg
convert camel_1.blur_4.jpg -blur $BLURFACTOR camel_1.blur_5.jpg

convert camel_2.jpg -blur $BLURFACTOR camel_2.blur_1.jpg
convert camel_2.blur_1.jpg -blur $BLURFACTOR camel_2.blur_2.jpg
convert camel_2.blur_2.jpg -blur $BLURFACTOR camel_2.blur_3.jpg
convert camel_2.blur_3.jpg -blur $BLURFACTOR camel_2.blur_4.jpg
convert camel_2.blur_4.jpg -blur $BLURFACTOR camel_2.blur_5.jpg

convert camel_3.jpg -blur $BLURFACTOR camel_3.blur_1.jpg
convert camel_3.blur_1.jpg -blur $BLURFACTOR camel_3.blur_2.jpg
convert camel_3.blur_2.jpg -blur $BLURFACTOR camel_3.blur_3.jpg
convert camel_3.blur_3.jpg -blur $BLURFACTOR camel_3.blur_4.jpg
convert camel_3.blur_4.jpg -blur $BLURFACTOR camel_3.blur_5.jpg

convert camel_4.jpg -blur $BLURFACTOR camel_4.blur_1.jpg
convert camel_4.blur_1.jpg -blur $BLURFACTOR camel_4.blur_2.jpg
convert camel_4.blur_2.jpg -blur $BLURFACTOR camel_4.blur_3.jpg
convert camel_4.blur_3.jpg -blur $BLURFACTOR camel_4.blur_4.jpg
convert camel_4.blur_4.jpg -blur $BLURFACTOR camel_4.blur_5.jpg

convert camel_8.jpg -blur $BLURFACTOR camel_8.blur_1.jpg
convert camel_8.blur_1.jpg -blur $BLURFACTOR camel_8.blur_2.jpg
convert camel_8.blur_2.jpg -blur $BLURFACTOR camel_8.blur_3.jpg
convert camel_8.blur_3.jpg -blur $BLURFACTOR camel_8.blur_4.jpg
convert camel_8.blur_4.jpg -blur $BLURFACTOR camel_8.blur_5.jpg

convert camel_10.jpg -blur $BLURFACTOR camel_10.blur_1.jpg
convert camel_10.blur_1.jpg -blur $BLURFACTOR camel_10.blur_2.jpg
convert camel_10.blur_2.jpg -blur $BLURFACTOR camel_10.blur_3.jpg
convert camel_10.blur_3.jpg -blur $BLURFACTOR camel_10.blur_4.jpg
convert camel_10.blur_4.jpg -blur $BLURFACTOR camel_10.blur_5.jpg
